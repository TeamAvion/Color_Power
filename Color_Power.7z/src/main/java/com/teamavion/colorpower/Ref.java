package com.teamavion.colorpower;

/**
 * Created by Tjken on 11/9/2016.
 */
public class Ref {

    public static final String MODID ="colorpower",
                    VERSION = "alpha 1";
}
