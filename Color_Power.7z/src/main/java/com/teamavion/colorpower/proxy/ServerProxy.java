package com.teamavion.colorpower.proxy;

/**
 * Created by Tjken on 11/9/2016.
 */
public class ServerProxy extends CommonProxy {
}
