package com.teamavion.colorpower.yellowpower.PipeApi;

/**
 * Created by Tjken on 11/13/2016.
 */
public interface IPipePacket {
    public void recivePacket(ItemPacket packet);
}
