package com.teamavion.colorpower.yellowpower.PipeApi;

import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

/**
 * Created by Tjken on 11/12/2016.
 */
public class ItemPacket {
    private ItemStack itemStack;
    private BlockPos targetPos;
    private int color;

    public ItemPacket(ItemStack itemStack, BlockPos targetPos){
        this.itemStack = itemStack;
        this.targetPos = targetPos;
        color = 0;
    }
    public ItemPacket(ItemStack itemStack, BlockPos targetPos, int color){
        this.itemStack = itemStack;
        this.targetPos = targetPos;
        this.color = color;
    }

    public BlockPos getTargetPos() {
        return targetPos;
    }

    public void setTargetPos(BlockPos targetPos) {
        this.targetPos = targetPos;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    public void reduceItemStack(int reduce){
        if (itemStack.stackSize - reduce > 0)
            itemStack.stackSize=- reduce;
        else
            itemStack = null;
    }

    /**
     * For internal use only
     * @param itemStack
     */
    @Deprecated
    public void setItemStack(ItemStack itemStack) {
        this.itemStack = itemStack;
    }
}
