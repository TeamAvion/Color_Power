package com.teamavion.colorpower.yellowpower.proxy;

/**
 * Created by Tjken on 11/9/2016.
 */
public class ClientProxy extends CommonProxy {
}
